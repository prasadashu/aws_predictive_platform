const aws = require('aws-sdk');

const sqs = new aws.SQS({
    apiVersion: '2012-11-05',
    endpoint: 'http://${process.env.LOCALSTACK_HOSTNAME}:4566'
});

exports.handler = async(event, context) => {
    const params = {
        DelaySeconds: 10,
        MessageBody: "Some more essage content sent from Lambda",
        QueueUrl: `http://${process.env.LOCALSTACK_HOSTNAME}:4566/000000000000/SomeQueueName`
    };
    try {
        const data = await sqs.sendMessage(params).promise();
        console.log("Success: ", data);
      } catch (error) {
        console.error("Error: ", error);
      }
}